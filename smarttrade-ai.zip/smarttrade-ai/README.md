# SmartTrade AI
Instruções para rodar o projeto.